[color=teal][size=2em][b]Font AweaZome [/b][/size][/color]
[b]Author:[/b] [url=http://zStudios.es]zStudios Networks[/url]

[color=teal][b][size=12pt]Description[/size][/b][/color]

[b]For SMF 2.0.x only[/b]

This mod will add a tags:  [nobbc]
[fa]fa-rebel[/fa]
 [/nobbc]
Using the Font Aweasome CDN for implement the Font Aweasome Icons via BBC  for the threads, and HTML for your forum templates.
[color=teal][b][size=12pt]License[/size][/b][/color]

 * This SMF modification is subject to the Mozilla Public License Version
 * 2.0 (the "License"); you may not use this SMF modification except in compliance with
 * the License. You may obtain a copy of the License at
 * [url=http://www.mozilla.org/MPL/]http://www.mozilla.org/MPL/[/url]
 
[color=teal][b][size=12pt]Languages[/size][/b][/color]
-English/utf8

[color=teal][b][size=12pt]Changelog[/size][/b][/color]

[b]1.0 - Jan 07, 2017[/b]
-Code improved.

[b]1.2 - May 18, 2017[/b]
-Stack Icons  feature added [b][fasi][/b]
[color=red][i][b]Note:[/b] For the usage of this modification we use the javascript CDN of Font Awesome, who has a function of error reports, any error from font awesome icon will be reported to their server..[/i][/color]